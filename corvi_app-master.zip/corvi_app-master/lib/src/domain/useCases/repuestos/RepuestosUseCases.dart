import 'package:corvi_app/src/domain/useCases/repuestos/RepuestosUseCase.dart';

class RepuestosUseCases {
  RepuestosUseCase repuestos;

  RepuestosUseCases({required this.repuestos});
}
