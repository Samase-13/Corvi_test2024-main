import 'package:corvi_app/src/domain/useCases/maquinaria/MaquinariaUseCase.dart';

// Clase contenedora para los casos de uso de maquinaria
class MaquinariaUseCases {
  final MaquinariaUseCase maquinaria; 

  MaquinariaUseCases({required this.maquinaria});
}
