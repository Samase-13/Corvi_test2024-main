class ApiConfig {
  static const String API = "192.168.0.104:5000";
}
// class ApiConfig {
//   static const String API =
//       "10.70.82.185:5000"; // Reemplaza con tu dirección IP local
// }
